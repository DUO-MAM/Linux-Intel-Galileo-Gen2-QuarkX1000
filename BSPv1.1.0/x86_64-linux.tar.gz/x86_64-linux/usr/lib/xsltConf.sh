#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/work/IntelGalileo/BSPv1.1.0/BSPv1.1.0/meta-clanton_v1.1.0-dirty/build/tmp/sysroots/x86_64-linux/usr/lib"
XSLT_LIBS="-lxslt  -L/work/IntelGalileo/BSPv1.1.0/BSPv1.1.0/meta-clanton_v1.1.0-dirty/build/tmp/sysroots/x86_64-linux/usr/lib -lxml2 -lz -lm -ldl -lm "
XSLT_INCLUDEDIR="-I/work/IntelGalileo/BSPv1.1.0/BSPv1.1.0/meta-clanton_v1.1.0-dirty/build/tmp/sysroots/x86_64-linux/usr/include"
MODULE_VERSION="xslt-1.1.28"
