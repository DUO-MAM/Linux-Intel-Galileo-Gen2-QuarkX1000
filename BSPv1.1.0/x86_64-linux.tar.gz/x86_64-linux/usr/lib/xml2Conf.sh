#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/work/IntelGalileo/BSPv1.1.0/BSPv1.1.0/meta-clanton_v1.1.0-dirty/build/tmp/sysroots/x86_64-linux/usr/lib"
XML2_LIBS="-lxml2 -lz   -lm "
XML2_INCLUDEDIR="-I/work/IntelGalileo/BSPv1.1.0/BSPv1.1.0/meta-clanton_v1.1.0-dirty/build/tmp/sysroots/x86_64-linux/usr/include/libxml2"
MODULE_VERSION="xml2-2.9.1"

